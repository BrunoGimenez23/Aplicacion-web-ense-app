from flask import Flask, request, redirect, url_for, session
from flask import render_template
from web.servicios import autenticacion

app = Flask(__name__)
app.secret_key = 'claveDificil123'


@app.route('/')
def cambio_Ruta():
    return redirect(url_for('index'))


@app.route('/index')
def index():
    return render_template('index.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if not autenticacion.validar_credenciales(request.form['login'], request.form['password']):
            error = 'Credenciales invalidas'
        else:
            session['user'] = request.form['login']
            return redirect(url_for('materias'))
    else:
        if 'user' in session:
            return render_template('login.html')
        return render_template('login.html', error=error)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    error = None
    if request.method == 'POST':
        if not autenticacion.crear_usuario(request.form['usuario'], request.form['clave']):
            error = 'No se puede crear el usuario'
        else:
            session['user'] = request.form['usuario']
            return redirect(url_for('login'))
    else:
        if 'user' in session:
            return render_template('signup.html')
    return render_template('signup.html', error=error)


@app.route('/materias')
def materias():
    usuarios = autenticacion.obtener_usuarios()
    return render_template('materias.html', usuarios=usuarios)


@app.route('/comentarios', methods=['POST', 'GET'])
def env_comentario():
    if "user" in session:
        commentarios = autenticacion.obtener_comentarios()
        commentarios.reverse()
        print(commentarios)
        if request.method == 'GET':
            return render_template('economicosysociales.html', commentarios=commentarios)
        elif request.method == 'POST':
            print(request.form['comment'])
            autenticacion.enviar_comentario(session['user'], request.form['comment'])
        return redirect(url_for('comentarios', usuario=session['user'], commentarios=commentarios))
    return redirect(url_for('index'))


@app.route('/comentarios')
def comentarios():
    if "user" not in session:
        return redirect(url_for('index'))
    else:
        return render_template('economicosysociales.html')


if __name__ == '__main__':
    app.debug = True
    app.run(port=5002)
