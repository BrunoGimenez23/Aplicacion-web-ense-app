from datos.base_de_datos import BaseDeDatos


def enviar_comentario(usuario, comentario):
    enviar_comentario_sql = f"""
        INSERT INTO COMENTARIOS (USUARIO, COMMENT)
        VALUES ('{usuario}','{comentario}')
    """
    bd = BaseDeDatos()
    bd.ejecutar_sql(enviar_comentario_sql)


def obtener_comentarios():
    obtener_comentarios_sql = f"""
        SELECT id_comentario, usuario, comment
        FROM COMENTARIOS
    """
    bd = BaseDeDatos()
    return [{"id_comentario": registro[0],
             "usuario": registro[1],
             "comment": registro[2]
             } for registro in bd.ejecutar_sql(obtener_comentarios_sql)]
