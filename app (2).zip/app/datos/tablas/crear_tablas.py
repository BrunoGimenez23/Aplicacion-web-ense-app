import sqlite3


sql_tabla_usuarios = '''
CREATE TABLE USUARIOS(
ID INTEGER PRIMARY KEY,
NOMBRE TEXT,
CLAVE TEXT,
ROL TEXT
)
'''

sql_tabla_sesiones = '''
CREATE TABLE SESIONES(
ID INTEGER PRIMARY KEY,
ID_USUARIO TEXT,
FECHA_HORA TEXT,
FOREIGN KEY(ID_USUARIO) REFERENCES USARIOS(ID_USUARIO)
)
'''

sql_tabla_comentarios = '''
CREATE TABLE COMENTARIOS(
ID_COMENTARIO INTEGER PRIMARY KEY,
USUARIO TEXT,
COMMENT TEXT,
FOREIGN KEY(ID_COMENTARIO) REFERENCES USUARIO(ID)
)
'''



if __name__ == '__main__':
    try:
        print('Creando Base de datos..')
        conexion = sqlite3.connect('../../Enseñapp.db')

        print('Creando Tablas..')
        conexion.execute(sql_tabla_usuarios)
        conexion.execute(sql_tabla_sesiones)
        conexion.execute(sql_tabla_comentarios)

        conexion.close()
        print('Creacion Finalizada.')
    except Exception as e:
        print(f'Error creando base de datos: {e}', e)
